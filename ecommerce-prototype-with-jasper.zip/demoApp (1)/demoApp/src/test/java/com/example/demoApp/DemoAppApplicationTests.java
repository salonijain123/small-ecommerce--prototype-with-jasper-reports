package com.example.demoApp;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demoApp.model.Product;
import com.example.demoApp.services.OrderService;

@SpringBootTest()
class DemoAppApplicationTests {

	@Autowired
	OrderService orderService;
	
	
	
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void insertOrderTest() {
		
		List<Product>  products = new ArrayList<>();
//		products.add(new Product(12L,"steerigm",2,50));
//		products.add(new Product(13L,"steerigm",2,100));

		
		//orderService.insertOrders(products);
		
	}

	
	
}
