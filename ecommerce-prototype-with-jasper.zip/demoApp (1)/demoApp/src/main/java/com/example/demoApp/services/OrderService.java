package com.example.demoApp.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoApp.model.OrderD;
import com.example.demoApp.model.Person;
import com.example.demoApp.model.Product;
import com.example.demoApp.repo.OrderRepo;
import com.example.demoApp.repo.PersonRepository;
import com.example.demoApp.repo.ProductRepository;

@Service
public class OrderService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	
	
	
	
	@Autowired
	private OrderRepo orderRepo;

	@Autowired
	ProductRepository productRepository;
	
	
	@Autowired
	PersonRepository personRepository;
	
	
	

	@Transactional
	public void insertOrders(List<Product> products,Long personId) {

		OrderD orderD = new OrderD();
		Product product1 = new Product();
		int totalAmount = 0;
		
		
		
		Optional<Person> pOptional1 = personRepository.findById(personId);
		
		orderD.setPerson(pOptional1.get());
         
		orderD.setOrderId(12L);
		
		for (Product product : products) {

			logger.info("product details" + product);

			Optional<Product> pOptional = productRepository.findById(product.getIdLong());

			int priceString = pOptional.get().getPriceString();
			logger.info("price string is" + priceString);

			int quantityString = product.getQuantity();

			logger.info("quantity String is" + quantityString);

			totalAmount = totalAmount + (quantityString * priceString);

			logger.info("total amount is" + totalAmount);

		}
		orderD.setAmountLong(totalAmount);

		orderD.setProducts(products);
		product1.addOrder(orderD);
		orderRepo.save(orderD);

		logger.info("order is" + orderD.toString());

	}
	
    	
}