
package com.example.demoApp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoApp.model.Person;
import com.example.demoApp.repo.PersonRepository;


@Service
public class PersonService {
	
	@Autowired
	PersonRepository pRepository;
	
	public List<Person>  getAllPersons() {
		
	List<Person>  persons=	pRepository.findAll();
		return persons;
		
	}
	
	public Person findOne(Long id) {
		
		Optional<Person> pOptional=pRepository.findById(id);
		Person person= pOptional.get();
		return person;
		
	}

	public void saveOrUpdate(Person person)   
	{  
	pRepository.save(person);  
	}  
	
	public void delete(Long id)   
	{  
	pRepository.deleteById(id);  
	}  
	
	public void update(Person person, Long id)   
	{  
		
	Person person2= findOne(id);
	if(person2 !=null) {
	person2.setNameString(person.getNameString());
	person2.setPhoneString(person.getPhoneString());
	pRepository.save(person2);  
	}
	}  
	
}