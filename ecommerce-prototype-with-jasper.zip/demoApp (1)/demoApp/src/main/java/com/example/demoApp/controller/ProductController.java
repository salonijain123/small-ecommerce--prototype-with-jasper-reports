package com.example.demoApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoApp.model.Product;
import com.example.demoApp.services.ProductService;

@RestController
public class ProductController {
	

	@Autowired
	ProductService productService;
	
	
	@GetMapping("/products/all")  
	private List<Product> getAllProducts()   
	{  
	return productService.getAllProducts();
	}  
	
	@GetMapping("/products/{id}")  
	private Product getSingleProduct(@PathVariable("id") Long id)   
	{  
	return productService.findOne(id);
	}  
	
	@DeleteMapping("/product/{id}")  
	private void deleteBook(@PathVariable("id") Long id)   
	{  
	productService.delete(id);
	}  
	
	

	@PutMapping("/product/update")  
	private void update(@RequestBody Product product,Long id)   
	{  
		      
		      
	   productService.update(product, id);
	}  

}
