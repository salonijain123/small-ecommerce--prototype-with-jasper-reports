package com.example.demoApp.model;

import java.util.List;


public class OrderReport {

	
	private String personNameString;
	private List<String> products;
	private int orderAmountString;
	private Long orderIdString;
	public String getPersonNameString() {
		return personNameString;
	}
	public List<String> getProducts() {
		return products;
	}
	public int getOrderAmountString() {
		return orderAmountString;
	}
	public Long getOrderIdString() {
		return orderIdString;
	}
	public void setPersonNameString(String personNameString) {
		this.personNameString = personNameString;
	}
	public void setProducts(List<String> products) {
		this.products = products;
	}
	public void setOrderAmountString(int orderAmountString) {
		this.orderAmountString = orderAmountString;
	}
	public void setOrderIdString(Long orderIdString) {
		this.orderIdString = orderIdString;
	}
	public OrderReport(String personNameString, List<String> products, int orderAmountString, Long orderIdString) {
		super();
		this.personNameString = personNameString;
		this.products = products;
		this.orderAmountString = orderAmountString;
		this.orderIdString = orderIdString;
	}
	public OrderReport() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
