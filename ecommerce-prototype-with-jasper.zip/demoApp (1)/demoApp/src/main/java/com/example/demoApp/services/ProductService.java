package com.example.demoApp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoApp.model.Product;
import com.example.demoApp.repo.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	ProductRepository pRepository;
	
	
	public List<Product>  getAllProducts() {
		
	List<Product>  products=	pRepository.findAll();
		return products;
		
	}
	
	public Product findOne(Long id) {
		
		Optional<Product> pOptional=pRepository.findById(id);
		Product product= pOptional.get();
		return product;
		
	}

	public void saveOrUpdate(Product product)   
	{  
		
	pRepository.save(product);  
	}  
	 
	public void delete(Long id)   
	{  
	pRepository.deleteById(id);  
	}  
	
	public void update(Product product, Long id)   
	{  
		
	Product product2= findOne(id);
	product2.setNameString(product.getNameString());
	pRepository.save(product2);
	
	}  

	
	
}
