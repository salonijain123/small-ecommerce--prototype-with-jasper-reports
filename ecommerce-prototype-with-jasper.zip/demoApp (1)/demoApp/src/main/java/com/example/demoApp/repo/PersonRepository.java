package com.example.demoApp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demoApp.model.Person;


@Repository
public interface PersonRepository extends JpaRepository<Person, Long> {

}
