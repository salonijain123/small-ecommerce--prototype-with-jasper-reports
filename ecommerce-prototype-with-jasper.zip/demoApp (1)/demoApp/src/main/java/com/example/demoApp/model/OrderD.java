
package com.example.demoApp.model;
 
 import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
 
 @Entity
 public class OrderD {
 	
 	@Id
 	@GeneratedValue
 	private Long orderId;
 	private int amountLong;
 	
 	 @ManyToOne(fetch = FetchType.LAZY)
 	    @JoinColumn(name = "person_id")
 	    private Person person;
 	 
 	@ManyToMany
	@JoinTable(name = "order_product_details", joinColumns = @JoinColumn(name = "order_id"), inverseJoinColumns = @JoinColumn(name = "product_id"))
	private List<Product> products = new ArrayList<>();

 
 	public Long getOrderId() {
 		return orderId;
 	}
 
 	public void setOrderId(Long orderId) {
 		this.orderId = orderId;
 	}
 
 	
 
 	public int getAmountLong() {
 		return amountLong;
 	}
 
 	public void setAmountLong(int amountLong) {
 		this.amountLong = amountLong;
 	}
 
 	public Person getPerson() {
 		return person;
 	}
 
 	public void setPerson(Person person) {
 		this.person = person;
 	}
 
 	
 
 	@Override
	public String toString() {
		return "OrderD [orderId=" + orderId +  ", amountLong="
				+ amountLong + ", person=" + person + ", products=" + products + "]";
	}

	public OrderD(Long orderId,int amountLong, Person person,
			List<Product> products) {
		super();
		this.orderId = orderId;
		
		this.amountLong = amountLong;
		this.person = person;
		this.products = products;
	}

	public List<Product> getProducts() {
 		return products;
 	}
 
 	public void setProducts(List<Product> products) {
 		this.products = products;
 	}
 
 	public OrderD() {
 		super();
 	}
 	
 	public void addProduct(Product product) {
		this.products.add(product);
	}


 	 
 	 
 
 }
