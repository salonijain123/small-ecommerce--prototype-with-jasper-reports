package com.example.demoApp.model;

 import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
 
 @Entity
 public class Product {
 	@Id
 	private Long idLong;
 	private String nameString;
 	private int priceString;
 	private Integer quantity;
 	
 	
 	public int getPriceString() {
		return priceString;
	}

	public void setPriceString(int priceString) {
		this.priceString = priceString;
	}

	@ManyToMany(mappedBy="products")
 	@JsonIgnore
 	private List<OrderD> orderD = new ArrayList<>();
 	
 	
 	 
 	
 	 @ManyToMany(targetEntity = Person.class,cascade = CascadeType.ALL )
 	 private List<Person> persons;
 
 	public Long getIdLong() {
 		return idLong;
 	}
 
 	public void setIdLong(Long idLong) {
 		this.idLong = idLong;
 	}
 
 	public String getNameString() {
 		return nameString;
 	}
 
 	public void setNameString(String nameString) {
 		this.nameString = nameString;
 	}
 
 	
 
 	
 
 	public List<Person> getPersons() {
 		return persons;
 	}
 
 	public void setPersons(List<Person> persons) {
 		this.persons = persons;
 	}
 
 	public Product() {
 		super();
 		  
 	}

	public List<OrderD> getOrderD() {
		return orderD;
	}

	public void setOrderD(List<OrderD> orderD) {
		this.orderD = orderD;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Product(Long idLong, String nameString,
			 int quantity,   List<OrderD> orderD, /* List<Person> persons*/int priceString) {
		super();
		this.idLong = idLong;
		this.nameString = nameString;
		this.orderD = orderD;
		//this.persons = persons;
		this.quantity=quantity;
		this.priceString=priceString;
	}

	@Override
	public String toString() {
		return "Product [idLong=" + idLong + ", nameString=" + nameString + ", priceString=" + priceString
				+ ", quantity=" + quantity + "]";
	}

	public void addOrder(OrderD o) {
		this.orderD.add(o);
	}
 
 
 	 
 	 
 	 
 	
 	
 
 }

