package com.example.demoApp.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Person {

	@Id
	private Long idLong;
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Person(Long idLong, String nameString, String phoneString
			,List<OrderD> detailsOrders,
			List<Product> products) {
		super();
		this.idLong = idLong;
	this.nameString = nameString;
	this.phoneString = phoneString;
		this.detailsOrders = detailsOrders;
		this.products = products;	}


	public Long getIdLong() {
		return idLong;
	}


	public void setIdLong(Long idLong) {
		this.idLong = idLong;
	}


	public String getNameString() {
		return nameString;
	}


	public void setNameString(String nameString) {
		this.nameString = nameString;
	}


	public String getPhoneString() {
		return phoneString;
	}


	public void setPhoneString(String phoneString) {
		this.phoneString = phoneString;
	}


	public List<OrderD> getDetailsOrders() {
		return detailsOrders;
	}


	public void setDetailsOrders(List<OrderD> detailsOrders) {
		this.detailsOrders = detailsOrders;
}


	public List<Product> getProducts() {
		return products;
	}


	public void setProducts(List<Product> products) {
		this.products = products;
	}


	private String nameString;
	private String phoneString;
	
  @OneToMany(cascade = CascadeType.ALL,
            fetch = FetchType.LAZY,
	            mappedBy = "person")
	    private List<OrderD> detailsOrders ;
  
	  
  @ManyToMany(targetEntity = Product.class,cascade = CascadeType.ALL,mappedBy ="persons" )
	 private List<Product> products;
	
	
		
}
