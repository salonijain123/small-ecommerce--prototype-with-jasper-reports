package com.example.demoApp.controller;

import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoApp.model.Product;
import com.example.demoApp.services.OrderService;
import com.example.demoApp.services.ReportService;

import net.sf.jasperreports.engine.JRException;

@RestController
public class OrderController {
	
	@Autowired
	OrderService orderService ;

	@Autowired
	ReportService reportService;
	
	@PostMapping("/orders/insert")
	public void insertOrderDetails(@RequestBody List<Product>  products,@RequestParam("personId") Long id) {
		
	orderService.insertOrders(products, id);
		
		
		
	}
	
	  @GetMapping("/report/{format}")
	    public String generateReport(@PathVariable String format) throws FileNotFoundException, JRException {
	        return reportService.exportReport(format);
	    }

	
}

