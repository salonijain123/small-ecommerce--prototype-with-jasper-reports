package com.example.demoApp.services;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.example.demoApp.model.OrderD;
import com.example.demoApp.model.OrderReport;
import com.example.demoApp.model.Product;
import com.example.demoApp.repo.OrderRepo;
import com.example.demoApp.repo.PersonRepository;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class ReportService {

    @Autowired
    private OrderRepo repository;
    
    @Autowired
    private PersonRepository personRepository;
    
    private List<OrderReport> orderReports  = new ArrayList();
    List<String>  strings = new ArrayList<>();


    public String exportReport(String reportFormat) throws FileNotFoundException, JRException {
        String path = "C:\\Users\\salon\\Desktop\\Report";
        OrderReport orderReport = new OrderReport();
        Optional< OrderD> orders = repository.findById(3L);
           
        for(Product product:orders.get().getProducts()) {
        	
        	       strings.add(product.getNameString());
        	 }
        
        orderReport.setOrderAmountString(orders.get().getAmountLong());
        orderReport.setOrderIdString(orders.get().getOrderId());
        orderReport.setPersonNameString(orders.get().getPerson().getNameString());
        orderReport.setProducts(strings);
        
        
     //   orderReport.setProducts(orders.get().getProducts());
        
        orderReports.add(orderReport);
        
        
        
        
        
        //load file and compile it
        File file = ResourceUtils.getFile("classpath:employees.jrxml");
        JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(orderReports);
        Map<String, Object> parameters = new HashMap<>();
        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
        if (reportFormat.equalsIgnoreCase("html")) {
            JasperExportManager.exportReportToHtmlFile(jasperPrint, path + "\\employees.html");
        }
        if (reportFormat.equalsIgnoreCase("pdf")) {
            JasperExportManager.exportReportToPdfFile(jasperPrint, path + "\\employees.pdf");
        }

        return "report generated in path : " + path;
    }
}
